/************************************************************************/
/*                                                                      */
/* This project exceedes the code size limits of the EK251 Eval Version */
/* and cannot be modified/retranslated with the EK251 Eval Version.     */
/*                                                                      */
/* However you can debug a pre-compiled version using dScope.           */
/*                                                                      */
/************************************************************************/

void main (void)  {
  /* This is a dummy main routine */
  while (1)  {
    ;
  }
}

