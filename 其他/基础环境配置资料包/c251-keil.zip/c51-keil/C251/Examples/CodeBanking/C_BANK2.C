#include <stdio.h>

void func2(void) {
  printf("THIS IS A FUNCTION IN BANK 2! \n");
}
